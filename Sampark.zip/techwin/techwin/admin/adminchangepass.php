



<?php

$conn=mysqli_connect("localhost","root","","techwin");


$email=$_POST['email'];
$opass=$_POST['opass'];
$npass=$_POST['npass'];



$query="select email,password from user where email='$email' and password='$opass'";

$data=mysqli_query($conn,$query);

$row=mysqli_fetch_array($data);
if($row)
{
	  $update="update user set password='$npass' where email='$email' and password='$opass'";
	  $up= mysqli_query($conn,$update);
	if($up)
	{
	   echo "<script>alert('Password Change Successfully');window.location.href='changepass.php'</script>";
	}
	
}
else
{
	echo "<script>alert('Email/Old Password Is Wrong');window.location.href='changepass.php'</script>";
}

?>
