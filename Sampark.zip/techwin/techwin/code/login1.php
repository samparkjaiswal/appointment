<?php
session_start();

$conn=mysqli_connect("localhost","root","","techwin");


$name=$_POST['name'];
$email=$_POST['email'];
$pass=$_POST['pass'];


$query="select email,password from user where email='$email' and password='$pass'";

$data=mysqli_query($conn,$query);

$row=mysqli_num_rows($data);

if($row>0)
{
	
	$_SESSION['admin']=$name;
	echo "<script>alert('Welcome to Dashboard');window.location.href='../admin/dash.php'</script>";
}
else
{
	echo "<script>alert('Wrong Username or Password');window.location.href='../login.php'</script>";
}





?>