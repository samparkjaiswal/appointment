<html>

<head>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

</head>
<body>
<center>
<table border="2px solid black" style="text-align:center" cellspacing="5">

<tr>
<th>Id</th>
<th>Name</th>
<th>Email</th>
<th>Phone</th>
<th colspan="2">Opration</th>

</center>
</tr>
<?php

$conn=mysqli_connect("localhost","root","","techwin");


$query="select * from user";

$data=mysqli_query($conn,$query);

while($res=mysqli_fetch_assoc($data))
{
	echo "
	
	<tr>
	<td>".$res['id']."</td>
	<td>".$res['name']."</td>
	<td>".$res['email']."</td>
	<td>".$res['mobile']."</td>
	<td><a href='delete.php?id=$res[id]' style='color:red'>Delete</a></td>
	<td><a href='update.php?id=$res[id]'>Update</a></td>
	</tr>
	
	";
}


?>

</table>
</body>
</html>