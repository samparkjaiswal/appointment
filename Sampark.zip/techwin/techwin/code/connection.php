<?php

$conn=mysqli_connect("localhost","root","");

if($conn)
{
	echo "Connection Success";
}
else
{
	echo "Connection failed";
}

?>