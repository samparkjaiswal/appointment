<?php

$conn=mysqli_connect("localhost","root","","techwin");

$id=$_GET['id'];

$sel="select * from user where id='$id'";

$query=mysqli_query($conn,$sel);

while($data=mysqli_fetch_assoc($query))
{
	$name=$data['name'];
	$email=$data['email'];
	$mobile=$data['mobile'];
}	

?>


<?php


if(isset($_POST['update']))
{
	$name=$_POST['name'];
	$email=$_POST['email'];
	$mobile=$_POST['mobile'];
	
	$update="update user set name='$name',email='$email',mobile='$mobile' where id='$id'";
	
	$qu=mysqli_query($conn,$update);
	if($qu)
	{
		echo "<script>alert('update sucessfully');window.location.href='../admin/registration.php'</script>";
	}
	else
	{
		echo "<script>alert('update failed');window.location.href='../admin/registration.php'</script>";
	}
}


?>




<html>

<head>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<title>Edit/Update Page</title>
</head>

<body>

<div class="container-fluid">

<div class="row">

<div class="col-md-4" style="min-height:300px"></div>
<div class="col-md-4" style="min-height:300px;border:2px solid black;border-radius:10px">

<h2 style="text-align:center;color:red;font-weight:900"><u>Edit/Update Form</u></h2>

<form action="" method="post">

<label>Name:</label>
<input type="text" name="name" class="form-control" value="<?php echo "$name" ?>" placeholder="Enter Your Name" required /><br>
<label>Email:</label>
<input type="email" name="email" class="form-control" value="<?php echo "$email" ?>" placeholder="Enter Your Email id" required /><br>

<label>Phone</label>
<input type="tel" name="mobile" class="form-control" value="<?php echo "$mobile" ?>" placeholder="Enter Your Mobile" required /><br><br>

<button type="submit" class="btn btn-success" name="update" style="width:100%" name="submit">Update</button><br><br>





</form>


</div>
<div class="col-md-4" style="min-height:300px"></div>

</div>

</div>

</body>

</html>