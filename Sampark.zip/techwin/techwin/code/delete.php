<?php
$conn=mysqli_connect("localhost","root","","techwin");

$id=$_GET['id'];

$del=mysqli_query($conn,"delete from user where id='$id'");
if($del)
{
	echo "<script>alert('Record Delete');window.location.href='../admin/registration.php'</script>";
}
else
{
	echo "<script>alert('Record Not Delete');window.location.href='../admin/registration.php'</script>";
}


?>