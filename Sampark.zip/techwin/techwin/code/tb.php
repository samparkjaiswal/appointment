<?php

$conn=mysqli_connect("localhost","root","","techwin");

$tb="create table user(id int(11) primary key auto_increment not null,name varchar(200),email varchar(200) unique,password varchar(200),mobile varchar(100))";

$tb1=mysqli_query($conn,$tb);

if($tb1)
{
	echo "table create";
}
else
{
	echo "table not create";
}

?>