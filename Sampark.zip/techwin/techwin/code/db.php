<?php
$conn=mysqli_connect("localhost","root","");
$db="create database techwin";

$db1=mysqli_query($conn,$db);

if($db1)
{
echo "Database create";
}
else
{
echo "db not create";
}


?>