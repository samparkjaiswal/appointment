<?php

$conn=mysqli_connect("localhost","root","","techwin");

$name=$_POST['name'];
$email=$_POST['email'];
$pass=$_POST['pass'];
$mobile=$_POST['mobile'];

$query="insert into user(name,email,password,mobile) values('$name','$email','$pass','$mobile')";

$data=mysqli_query($conn,$query);

if($data)
{
	echo "<script>alert('Registration Success');window.location.href='../reg.php'</script>";
}
else
{
	echo "<script>alert('Registration failed');window.location.href='../reg.php'</script>";
}

?>