<?php
//require "../model/model.php";
include "dash.php";
?>



<?php

if(isset($_SESSION['auth']))
{
  
   if($_SESSION['user_type'] == 2)
   {
    
   // header("location:dash.php");
   }
   elseif($_SESSION['user_type'] == 1)
   {
    header("location:userdash.php");
   }
}
else
{
    header("location:login.php");
}

?>





<html>
    <head>
  
    

    <style>
        .modal-header{
            background:orange;
            color:white;
        }
        .error{
	color:red;
	font-style:italic;
}
        
    </style>

    
<!--<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" />-->
</head>
<body>

<div class="container mt-3" style="margin-left:-4px">

<button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#myModal">Add Hospital</button>
<div class="modal" id="myModal">
    <div class="modal-dialog">
        <div class="modal-content">

            <div class="modal-header">
                <h5 class="modal-title">Add Hospital</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>


            <div class="modal-body">

            <form  method="post" action="../model/hoinsert.php" enctype="multipart/form-data" autocomplete="off"  id="sign">
						
						<div class="form-group">
							<label for="name">Hospital Name</label>
								<div class="input-group">
									<span class="input-group-addon"><i class="" aria-hidden="true"></i></span>
				<input type="text" class="form-control" name="hospital_name" id="name"  placeholder="Enter Hospital Name"/>
							</div>
						</div>

						<div class="form-group">
							<label for="department">Department</label>
								<div class="input-group">
									<span class="input-group-addon"><i class="" aria-hidden="true"></i></span>
									<input type="text" class="form-control" name="department" placeholder="Enter Department"/>
                                    
							</div>
						</div>

						<div class="form-group">
							<label for="email">Email</label>
								<div class="input-group">
									<span class="input-group-addon"><i class="" aria-hidden="true"></i></span>
									<input type="email" class="form-control" name="email" placeholder="Enter Email"/>
								</div>
                            </div>

						<div class="form-group">
							<label for="mobile">Mobile</label>
								<div class="input-group">
									<span class="input-group-addon"><i class="" aria-hidden="true"></i></span>
									<input type="tel" class="form-control" name="mobile" placeholder="Enter Contact"/>
								</div>
						</div>

						<div class="form-group">
							<label for="address">Address</label>
								<div class="input-group">
									<span class="input-group-addon"><i class="" aria-hidden="true"></i></span>
									
                                    <textarea name="address" class="form-control" placeholder="Enter Hospital Address"></textarea>
								</div>
						</div>


                        <div class="form-group">
							<label for="file">Hospital Image Upload</label>
								<div class="">
									
									<input type="file" class="form-control" name="file" placeholder=""/>
                                    
								</div>
						</div>
                        
                        <div class="form-group">
							<label for="name">Hospital Id</label>
								<div class="input-group">
									<span class="input-group-addon"><i class="" aria-hidden="true"></i></span>
				<input type="text" class="form-control" name="hosid" id="hosid"  placeholder="Enter Hospital Id"/>
							</div>
						</div>
                        
                        <br>



				<button type="submit" class="btn btn-success">SUBMIT</button>
						
					</form>
            
            </div>

        </div>
    </div>
</div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>

<h2 style="text-align:center;color:red;margin-top:;font-weight:900"><u>Hospital Record</u></h2>
    <center>
    
    <table class="table table-responsive" border="2px solid black" style="text-align:center">
<tr>

<th>Id</th>
<th>Hospitalname</th>
<th>Department</th>
<th>Email</th>
<th>Contact</th>
<th>Address</th>
<th>Image</th>
<th colspan="2">Operation</th>


</tr>

<?php

$rec=$obj->select_hospital();

/*
foreach($rec as $value)
{
   
   ?>
   <tr>
    <td><?php echo $value['id'];?></td>
    <td><?php echo $value['hospital_name'];?></td>
    <td><?php echo $value['department'];?></td>
    <td><?php echo $value['email'];?></td>
    <td><?php echo $value['mobile'];?></td>
    <td><?php echo $value['address'];?></td>
    <td><img src="<?php echo 'upload/'.$value['file'];?>" height="100px" width="100px" /></td>
</tr>
    
    
   <?php
}*/
//for image display this way so use concate
   foreach($rec as $value)
   {
    echo "
    <tr style='text-align:center'>
    <td>".$value['id']."</td>
    <td>".$value['hospital_name']."</td>
    <td>".$value['department']."</td>   
    <td>".$value['email']."</td>
    <td>".$value['mobile']."</td>
    <td>".$value['address']."</td>
    <td><img src=".'upload/'.$value['file']." height='70' width='70'></td>
    <td><a href='hoedit.php?eid=$value[id]'><button class='btn btn-warning'>Edit</button></a></td>
    <td><a href='../model/model.php?id=$value[id]'><button class='btn btn-danger'>Delete</button></a></td>

    </tr>";
   }



?>

</table>
</center>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.5/dist/jquery.validate.js"></script>
    <!-- when we need to additional library to digit etc -->
   <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.3/additional-methods.js"></script>-->
	<script src="hovalidate.js"></script>
</body>
</html>

