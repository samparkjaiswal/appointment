
<?php

//include "../model/session.php";
require "../model/model.php";



if(isset($_SESSION['auth']))
{
   if($_SESSION['user_type'] == 2)
   {
    header("location:dash.php");
   }
   elseif($_SESSION['user_type'] == 1)
   {
    //header("location:userdash.php");
    //echo $_SESSION['user_type'];
   }
}
else
{
    header("location:login.php");
}

?>


<!-- Latest compiled and minified CSS -->
<!--<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">-->

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" />

<!-- jQuery library -->
<!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>-->

<!-- Latest compiled JavaScript -->
<!--<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>-->

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<style>

    .row li{
        display:inline;
    }
</style>



    
    <div class="container-fluid">
        <div class="row" style="background:skyblue;min-height:100px"><h1 style="text-align:center;font-weight:bold;color:red;font-size:60px">Hospital Management</h1></div>
        
        <div class="row" style="background:lightgreen;min-height:50px">
        <ul style="list-style-type:none;margin-top:10px;">
            <li style=""><a href="userdash.php" style="color:black;text-decoration:none;font-size:20px;font-weight:bold"><span class="fa fa-home" style="color:red"></span> Home</a></li>
            <li style="margin-left:25px"><a href="diseasedisplay.php" style="color:black;text-decoration:none;font-size:20px;font-weight:bold"><span class="fa fa-user" style="color:red"></span> Disease Manage</a></li>
            
            <li style="float:right;margin-right:30px"><a href="../model/adminlogout.php" style="color:black;text-decoration:none;font-size:20px;font-weight:bold"><span class="fa fa-sign-out" style="color:red"></span> Logout</a></li>
            
        </ul>
        </div>
    </div>