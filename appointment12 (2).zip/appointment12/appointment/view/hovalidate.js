$(function(){
    var $horegister = $("#sign");
   $.validator.addMethod("noSpace", function(value, element){   //only for white space validation
    return value == "" || value.trim().length !=0
    }, "Spaces are not allowed");
    if($horegister.length)
    {
        $horegister.validate({
            rules:{
                hospital_name:{
                    required: true,
                    noSpace: true//if add method use then this property call
                   },
                department:{
                    required: true,
                    noSpace: true
                
                },
                email:{
                    required: true,
                    email: true,
                    noSpace: true
                },
                mobile:{
                    required: true,
                    minlength: 10,
                    maxlength: 12,
                  //  nowhitespace: true,
                    digits:true,
                   noSpace: true
                   
                   
                },
                address:{
                    required: true,
                  //  nowhitespace: true,
                    //lettersonly: true
                    noSpace: true
                },
                file:{
                    required: true,
                    
                }
            },
            
            messages:{
                hospital_name:{
                    required: "Please enter hospitalname!"
                },
                department:{
                    required: "Department is mandatory!"
                },
                email:{
                    required: "Please enter email!",
                    email: "Please enter valid email!"
                },
                mobile:{
                    required: "Please enter phone number!",
                    minlength: "Please enter atleast 10 charecter!",
                    maxlength: "Number not be greater than 12 digit!"
                },
                address:{
                    required: "Please enter address!"
                },
                file:{
                    required: "Please choose a file"
                }
                

            }
        })
    }
})