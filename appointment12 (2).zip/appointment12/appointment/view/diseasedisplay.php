<?php
include "userdash.php";


?>

<?php

if(isset($_SESSION['auth']))
{
   if($_SESSION['user_type'] == 2)
   {
    header("location:dash.php");
   }
   elseif($_SESSION['user_type'] == 1)
   {
   // header("location:userdash.php");
   //echo $_SESSION['disease_name'];
   }
}
else
{
    header("location:login.php");
}

?>




<html>
    <head>
    <h2 style="text-align:center;color:red"><u>Disease Record</u></h2>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" />
</head>
<body>
    <center>
    
    <table class="table table-responsive" border="2px solid black" style="text-align:center">
<tr>

<th>Id</th>
<th>Disease Name</th>
<th>Disease Symptoms</th>
<th>Operation</th>




</tr>

<?php
//require "../model/model.php";
$rec=$obj->select_diseas();

   foreach($rec as $value)
   {
    echo "
    <tr style='text-align:center'>
    
    <td>".$value['id']."</td>
    <td>".$value['disease_name']."</td>
    <td>".$value['disease_symptoms']."</td>
    
    
    <td><a href='dishospital.php?disid=$value[disid]'><button class='btn btn-primary'>Select</button></a></td>
    
   

    </tr>";
   }


?>

</table>
</center>

</body>
</html>