$(function(){
    var $login = $("#login-form");
    if($login.length)
    {
        $login.validate({
            rules:{
                email:{
                    required: true,
                    email: true
                },
                password:{
                    required: true,
                    minlength: 5
                }
                
            },
            
            messages:{
                email:{
                    required: "Please enter email!",
                    email: "Please enter valid email!"
                },
                password:{
                    required: "Please enter password!",
                    minlength: "Password must be atleast 5 charecter!"
                }
               
                

            }
        })
    }
})