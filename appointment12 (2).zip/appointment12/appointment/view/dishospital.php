<?php
//require "../model/model.php";
include "userdash.php";


?>

<?php

if(isset($_SESSION['auth']))
{
   
   if($_SESSION['user_type'] == 2)
   {
    
    header("location:dash.php");
   }
   elseif($_SESSION['user_type'] == 1)
   {
    //header("location:userdash.php");
	//echo $_SESSION['first_name'];
//	echo $_SESSION['user_type'];
	//echo $_SESSION['address'];
	
   }
}
else
{
    header("location:login.php");
}

?>


<html>
    <head>
    <h2 style="text-align:center;color:red"><u>Disease Record</u></h2>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" />

<style>
        .modal-header{
            background:green;
            color:white;
        }
        .error{
	color:red;
	font-style:italic;
}
        
    </style>

</head>
<body>
    <center>
    
    <table class="table table-responsive" border="2px solid black" style="text-align:center">
<tr>

<th>Id</th>
<th>Hospital Name</th>
<th>Department</th>
<th>Email</th>
<th>Contact</th>
<th>Address</th>



</tr>




<?php


$rec=$obj->select_dishos();
//print_r($ret);
   foreach($rec as $value)
   {
    echo "
    <tr style='text-align:center'>
    
    <td>".$value['id']."</td>
    <td>".$value['hospital_name']."</td>
    <td>".$value['department']."</td>
    <td>".$value['email']."</td>
    <td>".$value['mobile']."</td>
    <td>".$value['address']."</td>
    <td><a href='appointmentform.php?hosid=$value[hosid]'><button class='btn btn-info'>Select Hospital</button></a></td>
 
    
    
  
      </tr>";
   }


?>
</table>
</center>




<!--
<div class="container mt-3" style="margin-left:-4px">

<button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#myModal">Add Hospital</button>
<div class="modal" id="myModal">
    <div class="modal-dialog">
        <div class="modal-content">

            <div class="modal-header">
                <h5 class="modal-title">Appointment Form</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>


            <div class="modal-body">

            <form  method="post" action="" enctype="multipart/form-data" autocomplete="off"  id="sign">
						
						

						<div class="form-group">
							<label for="email">Firstname</label>
								<div class="input-group">
									<span class="input-group-addon"><i class="" aria-hidden="true"></i></span>
									<input type="text" class="form-control" value="<?php //echo $_SESSION['first_name'] ?>" name="first_name" placeholder=""/>
								</div>
                            </div>

						<div class="form-group">
							<label for="mobile">Lastname</label>
								<div class="input-group">
									<span class="input-group-addon"><i class="" aria-hidden="true"></i></span>
									<input type="text" class="form-control" value="<?php //echo $_SESSION['last_name'] ?>" name="last_name" placeholder=""/>
								</div>
						</div>

						<div class="form-group">
							<label for="address">Email</label>
								<div class="input-group">
									<span class="input-group-addon"><i class="" aria-hidden="true"></i></span>
									
                                    <input type="text" class="form-control" value="<?php //echo $_SESSION['email'] ?>" name="email" placeholder=""/>
								</div>
						</div>


                       
                        <div class="form-group">
							<label for="name">Mobile</label>
								<div class="input-group">
									<span class="input-group-addon"><i class="" aria-hidden="true"></i></span>
				<input type="tel" class="form-control" name="mobile" value="<?php //echo $_SESSION['mobile'] ?>" id="mobile"  placeholder=""/>
							</div>
						</div>

                        <div class="form-group">
							<label for="name">Address</label>
								<div class="input-group">
									<span class="input-group-addon"><i class="" aria-hidden="true"></i></span>
				<textarea name="address" class="form-control" id="address"><?php //echo $_SESSION['address'] ?></textarea>
							</div>
						</div>


                        <div class="form-group">
							<label for="name">Appointment Date</label>
								<div class="input-group">
									<span class="input-group-addon"><i class="" aria-hidden="true"></i></span>
				<input type="datetime-local" class="form-control" name="appointment_date" id="appointment_date"  placeholder=""/>
							</div>
						</div>

                        
                        <br>



				<button type="submit" class="btn btn-success">SUBMIT</button>
						
					</form>
            
            </div>

        </div>
    </div>
</div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>

-->
</body>
</html>