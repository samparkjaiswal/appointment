$(function(){
    var $register = $("#frm");
    $.validator.addMethod("noSpace", function(value, element){   //only for white space validation
        return value == "" || value.trim().length !=0
        }, "Spaces are not allowed");
    if($register.length)
    {
        $register.validate({
            rules:{
                first_name:{
                    required: true,
                  //  nowhitespace: true,
                   // lettersonly: true,
                   noSpace: true//if add method use then this property call
                },
                last_name:{
                    required: true,
                   // nowhitespace: true,
                 // lettersonly: true,
                   noSpace: true
                },
                email:{
                    required: true,
                    email: true
                   
                },
                password:{
                    required: true,
                    minlength: 5,
                   // noSpace: true
                },
                mobile:{
                    required: true,
                    minlength: 10,
                    maxlength: 12,
                    digits: true,
                   // nowhitespace: true
                  noSpace: true

                },
                address:{
                    required: true,
                   // nowhitespace: true
                    
                    noSpace: true
                },
            },
            
            messages:{
                first_name:{
                    required: "Please enter firstname!"
                },
                last_name:{
                    required: "Please enter lastname!"
                },
                email:{
                    required: "Please enter email!",
                    email: "Please enter valid email!"
                },
                password:{
                    required: "Please enter password!",
                    minlength: "Your password must be atleast 5 charecter!"
                },
                mobile:{
                    required: "Please enter phone number!",
                    minlength: "Please enter atleast 10 charecter!",
                    maxlength: "Number not be greater 12 digit!"
                },
                address:{
                    required: "Please enter address!"
                }
                

            }
        })
    }
})