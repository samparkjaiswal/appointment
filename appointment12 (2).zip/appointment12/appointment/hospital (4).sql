-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Aug 22, 2022 at 03:25 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 7.3.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hospital`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE `appointment` (
  `id` int(11) NOT NULL,
  `first_name` varchar(200) NOT NULL,
  `last_name` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `mobile` varchar(200) NOT NULL,
  `address` varchar(200) NOT NULL,
  `date` date NOT NULL,
  `disease_name` varchar(200) NOT NULL,
  `hospital_name` varchar(200) NOT NULL,
  `hospital_mobile` varchar(200) NOT NULL,
  `hospital_address` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `diseas`
--

CREATE TABLE `diseas` (
  `id` int(11) NOT NULL,
  `disease_name` varchar(200) NOT NULL,
  `disease_symptoms` varchar(300) NOT NULL,
  `disid` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `diseas`
--

INSERT INTO `diseas` (`id`, `disease_name`, `disease_symptoms`, `disid`) VALUES
(18, 'cancer', 'lung issues', '1'),
(19, 'eye', 'eye pain', '2');

-- --------------------------------------------------------

--
-- Table structure for table `hospi`
--

CREATE TABLE `hospi` (
  `id` int(11) NOT NULL,
  `hospital_name` varchar(200) NOT NULL,
  `department` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `mobile` varchar(200) NOT NULL,
  `address` varchar(200) NOT NULL,
  `file` varchar(200) NOT NULL,
  `hosid` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `hospi`
--

INSERT INTO `hospi` (`id`, `hospital_name`, `department`, `email`, `mobile`, `address`, `file`, `hosid`) VALUES
(32, 'ivy', 'eye', 'ivy@1234', '54545464545', 'delhi', 't.jpg', '2');

-- --------------------------------------------------------

--
-- Table structure for table `patient`
--

CREATE TABLE `patient` (
  `id` int(11) NOT NULL,
  `first_name` varchar(200) NOT NULL,
  `last_name` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `mobile` varchar(200) NOT NULL,
  `address` varchar(200) NOT NULL,
  `user_type` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `patient`
--

INSERT INTO `patient` (`id`, `first_name`, `last_name`, `email`, `password`, `mobile`, `address`, `user_type`) VALUES
(2, 'Sampark', 'Jaiswal', 's@123.com', '12345', '6392254020', 'Dubari Madhuban Mau', 1),
(3, 'Rohit', 'Maurya', 'ro@1234', '123123', '8081224669', 'Chauri Chaura Gorakhpur', 1),
(5, 'Admin', 'Detail', 'r@1234.com', '12345', '8765894438', 'Maharajganj', 2),
(6, 'Rajiv', 'Gupta', 'r@123gmail.com', '11111', '557575757876', 'moholi', 1),
(13, 'Rahul', 'Singh', 's@123', '12345', '8081224669', 'Dubari', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointment`
--
ALTER TABLE `appointment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `diseas`
--
ALTER TABLE `diseas`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hospi`
--
ALTER TABLE `hospi`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `patient`
--
ALTER TABLE `patient`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointment`
--
ALTER TABLE `appointment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `diseas`
--
ALTER TABLE `diseas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `hospi`
--
ALTER TABLE `hospi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `patient`
--
ALTER TABLE `patient`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
