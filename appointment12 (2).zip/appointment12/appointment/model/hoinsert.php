<?php
require "model.php";

$hos=array(

    'hospital_name'=>$_POST['hospital_name'],
    'department'=>$_POST['department'],
    'email'=>$_POST['email'],
    'mobile'=>$_POST['mobile'],
    'address'=>$_POST['address'],
    'hosid'=>$_POST['hosid']
   
);

$obj->hoinsert_data($hos);
?>