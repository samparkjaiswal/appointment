<?php
require "model.php";

$apparr=array(
    "datetime"=>$_POST['appointment_date'];
);

//$obj->appointment_ins($apparr);

?>